INSERT INTO user1 (name, fname, phone) VALUES
('John', 'Doe', '1234567890'),
('Jane', 'Smith', '2345678901'),
('Alice', 'Johnson', '3456789012'),
('Bob', 'Brown', '4567890123'),
('Charlie', 'Davis', '5678901234'),
('Emily', 'Miller', '6789012345'),
('Frank', 'Wilson', '7890123456'),
('Grace', 'Moore', '8901234567'),
('Hannah', 'Taylor', '9012345678'),
('Ian', 'Anderson', '0123456789');


INSERT INTO user1 (name, fname, phone) VALUES
('John', 'Doe', '1234567890'),
('Jane', 'Smith', '2345678901'),
('Alice', 'Johnson', '3456789012'),
('Bob', 'Brown', '4567890123'),
('Charlie', 'Davis', '5678901234'),
('Emily', 'Miller', '6789012345'),
('Frank', 'Wilson', '7890123456'),
('Grace', 'Moore', '8901234567'),
('Hannah', 'Taylor', '9012345678'),
('Ian', 'Anderson', '0123456789');
